'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { spawn } = require('node:child_process');
const prizes = require('../prizes');

async function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      server.close(() => resolve(port));
    });
    server.on('error', reject);
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

// One end-to-end test with a temporary private storage directory.
test('prize probabilities sum to 100 and are three exact 1% prizes', () => {
  assert.equal(prizes.reduce((sum, item) => sum + item.chance, 0), 100);
  assert.deepEqual(prizes.filter(item => item.chance === 1).map(item => item.id), ['follow', 'freestyle', 'comment']);
});

test('end-to-end: spins, cookies, repeat protection, admin, persistence', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'alexspin-'));
  const port = await freePort();
  const adminKey = 'test-secret-admin-key-is-long';
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
    cwd:path.join(__dirname, '..'),
    env:{...process.env,PORT:String(port),DATA_DIR:dir,ADMIN_KEY:adminKey,CAMPAIGN_ID:'test-campaign'},
    stdio:'ignore'
  });
  const url = `http://127.0.0.1:${port}`;
  try {
    let ready=false;
    for(let i=0;i<50;i++) {
      try{const r=await fetch(url+'/api/config');if(r.ok){ready=true;break;}}catch{}
      await sleep(100);
    }
    assert.equal(ready,true,'server should start');
    const config=await fetch(url+'/api/config');
    const cookie=config.headers.get('set-cookie')?.split(';')[0];
    assert.ok(cookie?.startsWith('alexspin='));
    const body=await config.json();
    assert.equal(body.prizes.length,8);
    assert.equal(body.alreadyPlayed,null);
    const invalid=await fetch(url+'/api/spin',{method:'POST',headers:{'Content-Type':'application/json','Cookie':cookie},body:JSON.stringify({username:'Bad name ???'})});
    assert.equal(invalid.status,400);
    const spin=await fetch(url+'/api/spin',{method:'POST',headers:{'Content-Type':'application/json','Cookie':cookie},body:JSON.stringify({username:'@UnitTestCreator'})});
    assert.equal(spin.status,200);
    const { result }=await spin.json();
    assert.equal(result.username,'unittestcreator');
    assert.ok(prizes.some(p=>p.id===result.prize.id));
    assert.equal(Boolean(result.code),result.prize.win);
    const repeated=await fetch(url+'/api/spin',{method:'POST',headers:{'Content-Type':'application/json','Cookie':cookie},body:JSON.stringify({username:'unittestcreator'})});
    assert.equal(repeated.status,409);
    const session=await fetch(url+'/api/config',{headers:{Cookie:cookie}});
    assert.equal((await session.json()).alreadyPlayed.id,result.id);
    const adminDenied=await fetch(url+'/api/admin/spins');
    assert.equal(adminDenied.status,401);
    const admin=await fetch(url+'/api/admin/spins',{headers:{'X-Admin-Key':adminKey}});
    assert.equal(admin.status,200);
    const items=(await admin.json()).spins;
    assert.equal(items.length,1);
    assert.equal(items[0].username,'unittestcreator');
    const csv=await fetch(url+'/api/admin/export',{headers:{'X-Admin-Key':adminKey}});
    assert.equal(csv.status,200);
    assert.ok((await csv.text()).includes('unittestcreator'));
    if(result.prize.win){
      const patch=await fetch(url+'/api/admin/spins/'+result.id,{method:'PATCH',headers:{'X-Admin-Key':adminKey,'Content-Type':'application/json'},body:JSON.stringify({status:'fulfilled'})});
      assert.equal(patch.status,200);
    }
    assert.equal(JSON.parse(fs.readFileSync(path.join(dir,'spins.json'),'utf8')).length,1);
    assert.ok(fs.existsSync(path.join(dir,'.cookie-secret')));
  } finally {
    child.kill();
    fs.rmSync(dir,{recursive:true,force:true});
  }
});
