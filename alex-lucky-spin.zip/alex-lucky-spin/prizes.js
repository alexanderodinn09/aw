// These odds are REAL server-side probabilities, not decorative wheel sizes.
// Keep the total at exactly 100. Changes apply to future spins only.
const PRIZES = [
  { id: 'follow', short: 'FOLLOW', title: 'Ég fylgi þér til baka', description: 'Alex fylgir TikTok-aðganginum þínum til baka.', chance: 1, color: '#e8ff57', win: true },
  { id: 'freestyle', short: 'FREESTYLE', title: 'Freestyle myndband með mér', description: 'Við skipuleggjum saman stutt freestyle-myndband.', chance: 1, color: '#b79bff', win: true },
  { id: 'comment', short: 'LIKE + COMMENT', title: 'Like og komment á myndband', description: 'Alex lækar og kommentar á eitt TikTok-myndband frá þér.', chance: 1, color: '#ff8d8e', win: true },
  { id: 'duet', short: 'DUETT', title: 'Duett eða stitch', description: 'Alex gerir duet eða stitch við eitt myndband frá þér.', chance: 2, color: '#76d5fb', win: true },
  { id: 'story', short: 'SHOUTOUT', title: 'Shoutout í story', description: 'Þú færð shoutout í TikTok-story hjá Alex.', chance: 5, color: '#febd6a', win: true },
  { id: 'question', short: 'SPURNING', title: 'Þú velur viðtalsspurningu', description: 'Þú mátt senda inn spurningu fyrir eitt af næstu viðtölunum mínum.', chance: 10, color: '#d8b7f0', win: true },
  { id: 'challenge', short: 'ÁSKORUN', title: 'Fyndin áskorun frá mér', description: 'Þú færð sérvalda fyndna áskorun í skilaboðum.', chance: 20, color: '#94e0b7', win: true },
  { id: 'nothing', short: 'EKKI NÚNA', title: 'Ekkert í þetta skiptið', description: 'Þetta var nálægt! Takk fyrir að taka þátt.', chance: 60, color: '#444652', win: false }
];

if (PRIZES.reduce((n, prize) => n + prize.chance, 0) !== 100) {
  throw new Error('Prize probabilities must total exactly 100%.');
}
module.exports = PRIZES;
