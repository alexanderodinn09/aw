@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js not found. Install Node.js 20+ from https://nodejs.org/
  pause
  exit /b 1
)
echo.
echo ALEX ODINN LUCKY SPIN
if not defined ADMIN_KEY (
  set /p "ADMIN_KEY=Set a private admin password (at least 16 characters): "
)
echo.
echo Website: http://localhost:3000
echo Dashboard: http://localhost:3000/admin
echo Keep this window open while running your website.
echo.
start "" "http://localhost:3000"
node server.js
pause
