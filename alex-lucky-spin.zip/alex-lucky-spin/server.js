'use strict';
/**
 * Alex Lucky Spin. Zero third-party dependencies.
 * For small, single-instance campaigns. Use a persistent DATA_DIR in production.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { URL } = require('node:url');
const PRIZES = require('./prizes');

const PORT = Number(process.env.PORT || 3000);
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const CAMPAIGN_ID = process.env.CAMPAIGN_ID || 'alex-launch-2026';
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const PUBLIC_DIR = path.join(__dirname, 'public');
const DB_PATH = path.join(DATA_DIR, 'spins.json');
const COOKIE_KEY_PATH = path.join(DATA_DIR, '.cookie-secret');
const ONE_HOUR = 60 * 60 * 1000;
const spinAttempts = new Map();

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, '[]\n', { flag: 'wx' });
if (!fs.existsSync(COOKIE_KEY_PATH)) fs.writeFileSync(COOKIE_KEY_PATH, crypto.randomBytes(48).toString('hex'), { flag: 'wx', mode: 0o600 });
const cookieKey = fs.readFileSync(COOKIE_KEY_PATH, 'utf8').trim();
let spins = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
if (!Array.isArray(spins)) throw new Error('Invalid spins.json file');

function save() {
  const tmp = `${DB_PATH}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(spins, null, 2) + '\n');
  fs.renameSync(tmp, DB_PATH);
}
function hash(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function sign(value) { return crypto.createHmac('sha256', cookieKey).update(value).digest('hex'); }
function safeEqual(a, b) {
  if (!a || !b) return false;
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
function getCookie(req, key) {
  return (req.headers.cookie || '').split(';').map(x => x.trim()).find(x => x.startsWith(key + '='))?.slice(key.length + 1) || '';
}
function getSid(req, res) {
  const cookie = getCookie(req, 'alexspin');
  const match = /^([a-f0-9]{48})\.([a-f0-9]{64})$/.exec(cookie);
  if (match && safeEqual(sign(match[1]), match[2])) return match[1];
  const sid = crypto.randomBytes(24).toString('hex');
  const secure = Boolean(req.socket.encrypted) || req.headers['x-forwarded-proto'] === 'https';
  res.setHeader('Set-Cookie', `alexspin=${sid}.${sign(sid)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${secure ? '; Secure' : ''}`);
  return sid;
}
function api(res, status, data, extraHeaders = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extraHeaders });
  res.end(JSON.stringify(data));
}
function jsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 8000) { reject(new Error('Too much data')); req.destroy(); }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); } catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}
function normalizeHandle(input) {
  if (typeof input !== 'string') return null;
  const handle = input.trim().replace(/^@/, '').toLowerCase();
  return /^[a-z0-9._]{2,24}$/.test(handle) ? handle : null;
}
function getPrize(id) { return PRIZES.find(p => p.id === id); }
function publicSpin(record) {
  if (!record) return null;
  const prize = getPrize(record.prizeId);
  return {
    id: record.id,
    username: record.username,
    prize: { id: prize.id, title: prize.title, description: prize.description, win: prize.win },
    code: prize.win ? record.code : null,
    createdAt: record.createdAt,
    status: record.status
  };
}
function pickPrize() {
  const ticket = crypto.randomInt(100); // unbiased: tickets 0..99
  let ceiling = 0;
  for (const prize of PRIZES) {
    ceiling += prize.chance;
    if (ticket < ceiling) return prize;
  }
  throw new Error('Invalid odds');
}
function isRateLimited(sid) {
  const now = Date.now();
  const previous = (spinAttempts.get(sid) || []).filter(t => now - t < ONE_HOUR);
  previous.push(now);
  spinAttempts.set(sid, previous);
  if (spinAttempts.size > 10000) for (const [k, timestamps] of spinAttempts) {
    if (!timestamps.some(t => now - t < ONE_HOUR)) spinAttempts.delete(k);
  }
  return previous.length > 6;
}
function adminAuthorized(req) {
  return ADMIN_KEY.length >= 16 && safeEqual(req.headers['x-admin-key'], ADMIN_KEY);
}
function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try { return new URL(origin).host === req.headers.host; } catch { return false; }
}
function sendCsv(res) {
  const rows = [['Dags.', 'TikTok', 'Vinningur', 'Kóði', 'Staða', 'Herferð']];
  for (const s of spins) rows.push([s.createdAt, '@' + s.username, getPrize(s.prizeId)?.title || s.prizeId, s.code || '', s.status, s.campaignId]);
  const csv = '\ufeff' + rows.map(row => row.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\r\n');
  res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="alex-winners.csv"', 'Cache-Control': 'no-store' });
  res.end(csv);
}
function serveStatic(req, res, pathname) {
  const route = pathname === '/' ? 'index.html' : pathname === '/admin' ? 'admin.html' : pathname.slice(1);
  let decoded;
  try { decoded = decodeURIComponent(route); } catch { return api(res, 400, { error: 'Invalid path' }); }
  if (!decoded || decoded.split('/').some(part => part.startsWith('.')) || decoded.includes('\\')) return api(res, 404, { error: 'Not found' });
  const filepath = path.resolve(PUBLIC_DIR, decoded);
  if (!filepath.startsWith(PUBLIC_DIR + path.sep)) return api(res, 404, { error: 'Not found' });
  const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
  fs.readFile(filepath, (err, data) => {
    if (err) return api(res, 404, { error: 'Not found' });
    const type = types[path.extname(filepath)] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': `${type}; charset=utf-8`, 'Cache-Control': 'public, max-age=180' });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'");
  try {
    const pathname = new URL(req.url, 'http://localhost').pathname;
    if (pathname === '/api/config' && req.method === 'GET') {
      const sid = getSid(req, res);
      const existing = spins.find(s => s.campaignId === CAMPAIGN_ID && s.sidHash === hash(sid));
      return api(res, 200, { campaignId: CAMPAIGN_ID, prizes: PRIZES, alreadyPlayed: publicSpin(existing) });
    }
    if (pathname === '/api/spin' && req.method === 'POST') {
      if (!sameOrigin(req)) return api(res, 403, { error: 'Óleyfileg beiðni.' });
      const sid = getSid(req, res);
      if (isRateLimited(sid)) return api(res, 429, { error: 'Of margar tilraunir. Prófaðu aftur síðar.' });
      const { username } = await jsonBody(req);
      const handle = normalizeHandle(username);
      if (!handle) return api(res, 400, { error: 'Sláðu inn gilt TikTok-notandanafn.' });
      const earlier = spins.find(s => s.campaignId === CAMPAIGN_ID && s.sidHash === hash(sid));
      if (earlier) return api(res, 409, { error: 'Þú hefur þegar snúið hjólinu.', alreadyPlayed: publicSpin(earlier) });
      if (spins.some(s => s.campaignId === CAMPAIGN_ID && s.username === handle)) {
        return api(res, 409, { error: 'Þetta TikTok-notandanafn hefur þegar tekið þátt.' });
      }
      const prize = pickPrize();
      const record = {
        id: crypto.randomUUID(), campaignId: CAMPAIGN_ID, username: handle,
        sidHash: hash(sid), prizeId: prize.id,
        code: prize.win ? crypto.randomBytes(4).toString('hex').toUpperCase() : null,
        status: prize.win ? 'pending' : 'none', createdAt: new Date().toISOString()
      };
      spins.push(record);
      save();
      return api(res, 200, { result: publicSpin(record) });
    }
    if (pathname === '/api/admin/spins' && req.method === 'GET') {
      if (!adminAuthorized(req)) return api(res, 401, { error: 'Rangur aðgangslykill eða stjórnborð óvirkt.' });
      return api(res, 200, { campaignId: CAMPAIGN_ID, spins: spins.filter(s => s.campaignId === CAMPAIGN_ID).map(s => ({
        id: s.id, username: s.username, prizeId: s.prizeId, prizeTitle: getPrize(s.prizeId)?.title || s.prizeId,
        won: Boolean(getPrize(s.prizeId)?.win), code: s.code, status: s.status, createdAt: s.createdAt
      })).reverse() });
    }
    if (pathname === '/api/admin/export' && req.method === 'GET') {
      if (!adminAuthorized(req)) return api(res, 401, { error: 'Unauthorized' });
      return sendCsv(res);
    }
    const adminMatch = /^\/api\/admin\/spins\/([a-f0-9-]+)$/.exec(pathname);
    if (adminMatch && req.method === 'PATCH') {
      if (!sameOrigin(req) || !adminAuthorized(req)) return api(res, 401, { error: 'Unauthorized' });
      const { status } = await jsonBody(req);
      const record = spins.find(s => s.id === adminMatch[1] && s.campaignId === CAMPAIGN_ID);
      if (!record) return api(res, 404, { error: 'Vinningur fannst ekki.' });
      if (!getPrize(record.prizeId)?.win) return api(res, 400, { error: 'Enginn vinningur.' });
      if (!['pending', 'fulfilled', 'rejected'].includes(status)) return api(res, 400, { error: 'Ógild staða.' });
      record.status = status;
      save();
      return api(res, 200, { ok: true });
    }
    if ((req.method === 'GET' || req.method === 'HEAD') && !pathname.startsWith('/api/')) {
      return serveStatic(req, res, pathname);
    }
    return api(res, 404, { error: 'Not found' });
  } catch (error) {
    console.error('Request error:', error);
    if (!res.headersSent) api(res, 500, { error: 'Villa kom upp. Reyndu aftur.' });
    else res.end();
  }
});
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\nAlex Lucky Spin running at http://localhost:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin ${ADMIN_KEY.length >= 16 ? '(enabled)' : '(disabled: set ADMIN_KEY, min. 16 chars)'}`);
  console.log(`Data directory: ${DATA_DIR}\n`);
});
