# ALEX ODINN — LUCKY SPIN

A custom, mobile-friendly prize wheel inspired by the Halloween campaign landing page at https://hjolid.nings.is/. This is an **original implementation**, not a copy of Nings' source code, branding, or artwork.

## Included

- Icelandic, dark-mode landing page with a responsive animated wheel.
- **Real weighted outcomes calculated on the server** with cryptographically secure randomness.
- Three exact 1% rewards: follow-back, freestyle collaboration, and like + comment.
- Public list of the true probability for every prize.
- A TikTok username entry form and one spin per username **per campaign**.
- Signed browser cookie to discourage repeat spins. Records persist in a JSON file.
- Winner verification codes displayed after winning, for you to verify by TikTok DM.
- Private `/admin` dashboard with entries, claim codes, status changes, stats and CSV export.
- No database, npm packages, or paid API required for this starter version.
- A clearly labeled **preview-only mode** if the page is opened without a working backend. Preview prizes do not count and are not redeemable.

## Start it on your Windows PC

1. Install **Node.js 20 or newer** from https://nodejs.org/.
2. Extract the ZIP.
3. **Easiest:** double-click `START-WINDOWS.bat`, enter a 16+ character private admin password, and it opens the site for you. Or open a terminal (PowerShell) inside the `alex-lucky-spin` folder and continue below.
4. Set your private admin key (choose your own unpredictable string, at least 16 characters):

   ```powershell
   $env:ADMIN_KEY="choose-a-really-long-random-secret-here"
   ```

5. Start the server:

   ```powershell
   npm start
   ```

6. Open http://localhost:3000 for the game and http://localhost:3000/admin for your dashboard. Enter the same admin key in the dashboard.

**No `npm install` is required:** all backend modules are built into Node.js.

### macOS / Linux

```bash
ADMIN_KEY="choose-a-really-long-random-secret-here" npm start
```

### Quick visual preview

You can open `public/index.html` in a browser to inspect the design, but **it runs in demo mode**. Use `npm start` for real spins and persistent results.

## Customize your wheel

Change `prizes.js`:

```js
{ id: 'follow', short: 'FOLLOW', title: 'Ég fylgi þér til baka', description: '...', chance: 1, color: '#e8ff57', win: true }
```

- `chance` is the actual % for one spin. **All percentages must add to 100** or the server refuses to launch.
- `short` is the label printed on the wheel. Keep this short, ideally under 12 characters.
- `title`, `description`, and `color` appear in the wheel/prize list/results.
- `win: false` means no prize and no claim code.
- The wheel displays **equal-sized decorative slices** for readability. The probabilities in the prize list, not the physical slice sizes, are used for the draw. The site explicitly tells users this.
- The preview-mode version of the same prize list is in `public/app.js` under `FALLBACK_PRIZES`. If you want your offline preview to match, change it there as well.
- Change color/font/design in `public/styles.css`, page copy in `public/index.html`.
- Your TikTok profile URL is currently `https://www.tiktok.com/@alex_odinn`.

## How claims work

1. A visitor enters their TikTok username and spins.
2. `/api/spin` makes one draw server-side and saves the result **before** sending it back.
3. If the visitor wins, they receive a claim code.
4. They DM you from the **same** TikTok account and provide the code.
5. You use `/admin` to check username, code, and prize, then mark as *fulfilled* or *rejected*.

**Important:** This starter does **not** connect to TikTok APIs. It does not automatically follow, like, comment, send DMs, or verify account ownership. You perform the prizes manually. Do not promise prizes you cannot realistically deliver.

## Go live with your own website

Use a host that runs a long-lived **Node.js server with persistent disk storage** (for example, a paid Render or Railway service with a persistent volume):

1. Upload the project to a private GitHub repository (without the `data/` directory or secrets).
2. Create a Node web service. Start command: `npm start`. A build command is not required.
3. Set `ADMIN_KEY` (a unique long secret), `CAMPAIGN_ID` (e.g. `alex-nov-2026`), and `DATA_DIR` (directory on a **persistent mounted volume**). The host typically sets `PORT` automatically.
4. Connect a domain, enable HTTPS and test the admin page, cookies, and claim flow.
5. Keep backups of `data/spins.json` and `data/.cookie-secret`.

**Don't deploy this as static-only HTML**, because static hosting cannot securely enforce odds or save verified winning claims. **Don't use ephemeral storage for real prize campaigns**, because it may wipe past entries after redeployment. For large campaigns or stronger anti-abuse protection, migrate to a real database, bot protection, and verified identity/login.

## Fairness, privacy and security limits

- This implementation uses `crypto.randomInt(100)` on the server. Every spin is independently drawn with precisely the configured percentage weights.
- Users can still create fresh usernames or impersonate another person. The site does not prove ownership of the username, so account verification happens by DM. For substantial prizes or many participants, add TikTok OAuth (if available for your app), CAPTCHA, and server-side anti-abuse controls.
- A 1% chance **does not** guarantee that exactly one in every 100 visitors wins.
- The server stores TikTok username, result, claim code, hashed cookie session identifier, timestamp and claim status. It does not permanently store IP addresses. Put a privacy policy and your contact information on the site before launching it publicly. Back up and delete the participant data once no longer needed.
- No purchase, follows, likes or payments are required to enter. Review current local promotion rules and TikTok platform rules before publishing, especially if you expand into physical goods or paid entries.
- This JSON-file version assumes a **single Node.js server process**. Running multiple instances against the same file can cause data loss or duplicate draws. For multi-instance production use a database and atomic uniqueness constraints.
- To start a **new campaign**, set a new `CAMPAIGN_ID` in the environment before starting. Earlier records stay in the JSON file; the site will treat the new campaign as fresh.

## Files

```
alex-lucky-spin/
├── server.js             # API, secure random draws, claims, data storage
├── prizes.js             # The actual prize probabilities
├── package.json          # npm start, no external dependencies
├── .env.example          # Environment settings reference
├── START-WINDOWS.bat     # Double-click launcher for Windows
├── public/
│   ├── index.html        # Contest landing page
│   ├── styles.css        # Design and mobile layout
│   ├── app.js            # Interactive wheel and animations
│   ├── admin.html        # Private claim dashboard
│   ├── admin.css
│   └── admin.js
└── data/                 # Generated automatically; private, do not publish
```
