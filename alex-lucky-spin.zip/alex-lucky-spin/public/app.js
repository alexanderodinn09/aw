'use strict';

const FALLBACK_PRIZES = [
  { id:'follow', short:'FOLLOW', title:'Ég fylgi þér til baka', description:'Alex fylgir TikTok-aðganginum þínum til baka.', chance:1, color:'#e8ff57', win:true },
  { id:'freestyle', short:'FREESTYLE', title:'Freestyle myndband með mér', description:'Við skipuleggjum saman stutt freestyle-myndband.', chance:1, color:'#b79bff', win:true },
  { id:'comment', short:'LIKE + COMMENT', title:'Like og komment á myndband', description:'Alex lækar og kommentar á eitt TikTok-myndband frá þér.', chance:1, color:'#ff8d8e', win:true },
  { id:'duet', short:'DUETT', title:'Duett eða stitch', description:'Alex gerir duet eða stitch við eitt myndband frá þér.', chance:2, color:'#76d5fb', win:true },
  { id:'story', short:'SHOUTOUT', title:'Shoutout í story', description:'Þú færð shoutout í TikTok-story hjá Alex.', chance:5, color:'#febd6a', win:true },
  { id:'question', short:'SPURNING', title:'Þú velur viðtalsspurningu', description:'Þú mátt senda inn spurningu fyrir eitt af næstu viðtölunum mínum.', chance:10, color:'#d8b7f0', win:true },
  { id:'challenge', short:'ÁSKORUN', title:'Fyndin áskorun frá mér', description:'Þú færð sérvalda fyndna áskorun í skilaboðum.', chance:20, color:'#94e0b7', win:true },
  { id:'nothing', short:'EKKI NÚNA', title:'Ekkert í þetta skiptið', description:'Þetta var nálægt! Takk fyrir að taka þátt.', chance:60, color:'#444652', win:false }
];

const $ = id => document.getElementById(id);
const svgNS = 'http://www.w3.org/2000/svg';
const wheel = $('wheel');
const form = $('spin-form');
const input = $('username');
const spinButton = $('spin-button');
const feedback = $('form-feedback');
let prizes = FALLBACK_PRIZES;
let isDemo = false;
let alreadyPlayed = null;
let isSpinning = false;
let lastFocus = null;

function svgEl(tag, attrs = {}, text) {
  const node = document.createElementNS(svgNS, tag);
  for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, value);
  if (text !== undefined) node.textContent = text;
  return node;
}
function polar(cx, cy, radius, degrees) {
  const rad = degrees * Math.PI / 180;
  return { x: cx + radius * Math.sin(rad), y: cy - radius * Math.cos(rad) };
}
function buildWheel() {
  wheel.innerHTML = '';
  const cx = 220, cy = 220, r = 209;
  const slice = 360 / prizes.length;
  prizes.forEach((prize, i) => {
    const start = i * slice, end = (i + 1) * slice, mid = start + slice / 2;
    const a = polar(cx, cy, r, start), b = polar(cx, cy, r, end);
    const largeArc = slice > 180 ? 1 : 0;
    const path = `M ${cx} ${cy} L ${a.x} ${a.y} A ${r} ${r} 0 ${largeArc} 1 ${b.x} ${b.y} Z`;
    wheel.appendChild(svgEl('path', {d:path,fill:prize.color,class:'sector'}));
    const p = polar(cx, cy, 140, mid);
    const dark = i !== prizes.length - 1;
    const readableRotation = mid > 90 && mid < 270 ? mid - 180 : mid;
    const text = svgEl('text', {
      x:p.x,y:p.y,class:`sector-label${dark?'':' light'}`,
      'text-anchor':'middle','dominant-baseline':'central',
      transform:`rotate(${readableRotation} ${p.x} ${p.y})`
    }, prize.short);
    // Limit the visual width of the labels inside each wedge.
    text.setAttribute('textLength', String(Math.min(prize.short.length * 8.3, 121)));
    text.setAttribute('lengthAdjust', 'spacingAndGlyphs');
    wheel.appendChild(text);
  });
  wheel.appendChild(svgEl('circle',{cx,cy,r:213,class:'wheel-outline'}));
  for (let i = 0; i < 32; i++) {
    const p = polar(cx,cy,201,i * 360/32);
    wheel.appendChild(svgEl('circle',{cx:p.x,cy:p.y,r:2.4,class:'wheel-stud'}));
  }
}
function buildPrizes() {
  const list = $('prize-list');
  list.replaceChildren();
  for (const [i, prize] of prizes.entries()) {
    const card = document.createElement('article');
    card.className = 'prize-card';
    card.style.setProperty('--prize-color',prize.color);
    const top = document.createElement('div'); top.className = 'prize-top';
    const dot = document.createElement('span'); dot.className = 'prize-color';dot.setAttribute('aria-hidden','true');
    const percent = document.createElement('span');percent.className = 'prize-percent';percent.textContent = `${prize.chance}%`;
    top.append(dot,percent);
    const heading = document.createElement('h3');heading.textContent = prize.title;
    const description = document.createElement('p');description.textContent = prize.description;
    const index = document.createElement('span'); index.className='prize-index';index.textContent = String(i+1).padStart(2,'0');
    card.append(top,heading,description,index);
    list.appendChild(card);
  }
}
function setMessage(message, isError=false) {
  feedback.textContent = message;
  feedback.classList.toggle('error',isError);
}
function setPlayed(result) {
  alreadyPlayed = result;
  input.value = result.username || '';
  input.disabled = true;
  spinButton.textContent = 'ÚTKOMA ↗';
  spinButton.disabled = false;
  setMessage('Þú hefur þegar snúið hjólinu. Smelltu á ÚTKOMA til að sjá niðurstöðuna.');
}
function pickDemoPrize() {
  const bytes = new Uint32Array(1);
  if (window.crypto?.getRandomValues) window.crypto.getRandomValues(bytes);
  else bytes[0] = Math.floor(Math.random() * 2**32);
  // Use rejection sampling to avoid modulo bias.
  let n = bytes[0];
  const max = Math.floor(2**32 / 100) * 100;
  if (window.crypto?.getRandomValues) while (n >= max) { window.crypto.getRandomValues(bytes); n = bytes[0]; }
  let ticket = n % 100;
  for (const prize of prizes) {
    if (ticket < prize.chance) return prize;
    ticket -= prize.chance;
  }
  return prizes[prizes.length-1];
}
async function loadConfig() {
  try {
    if (location.protocol === 'file:') throw new Error('File preview');
    const response = await fetch('/api/config',{cache:'no-store',credentials:'same-origin'});
    if (!response.ok) throw new Error('Backend unavailable');
    const data = await response.json();
    if (!Array.isArray(data.prizes) || data.prizes.reduce((t,p)=>t+p.chance,0)!==100) throw new Error('Invalid configuration');
    prizes = data.prizes;
    if (data.alreadyPlayed) setPlayed(data.alreadyPlayed);
  } catch (err) {
    console.info('Preview mode:',err.message);
    isDemo = true;
    $('demo-alert').hidden = false;
    setMessage('Prufuhamur. Prófaðu hjólið án þess að sækja raunverulegan vinning.');
  }
  buildWheel();
  buildPrizes();
  spinButton.disabled = false;
}
function showResult(result, demo=false) {
  const prize = result.prize;
  const won = Boolean(prize.win);
  lastFocus = document.activeElement;
  $('result-sparkle').textContent = won ? '✳' : '↻';
  $('result-kicker').textContent = won ? 'ÞÚ UNNST!' : 'EKKI ÞÍN HEPPNI Í DAG';
  $('result-title').textContent = won ? prize.title.toUpperCase() : 'NÆSTUM ÞVÍ!';
  $('result-description').textContent = won ? prize.description : 'Þú fékkst ekki vinning í þetta skiptið. Takk fyrir að snúa hjólinu!';
  $('claim-area').hidden = !won || demo || !result.code;
  $('claim-code').textContent = !demo ? (result.code || '') : '';
  $('demo-result-label').hidden = !demo;
  $('result-main-link').textContent = won && !demo ? 'SENDA MÉR DM ↗' : 'SKOÐA TIKTOK ↗';
  $('result-overlay').hidden = false;
  document.body.style.overflow = 'hidden';
  document.querySelector('.result-modal').focus();
  if (won) confetti();
}
function hideResult() {
  $('result-overlay').hidden = true;
  document.body.style.overflow = '';
  lastFocus?.focus?.();
}
function confetti() {
  const container = $('confetti');
  container.replaceChildren();
  const colors = ['#e6ff53','#b79bff','#ff8d8e','#e9e8e4','#76d5fb'];
  const count = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 80;
  for (let i=0;i<count;i++) {
    const piece=document.createElement('span');piece.className='confetti-piece';
    piece.style.setProperty('--left', `${Math.random()*100}%`);
    piece.style.setProperty('--duration',`${3 + Math.random()*3}s`);
    piece.style.setProperty('--piece-color', colors[Math.floor(Math.random()*colors.length)]);
    piece.style.setProperty('--rot',`${Math.random()*360}deg`);
    piece.style.setProperty('--drift',`${(Math.random()-.5)*350}px`);
    piece.style.animationDelay=`${Math.random()*.9}s`;
    container.appendChild(piece);
  }
  setTimeout(()=>container.replaceChildren(),7400);
}
async function spin(result) {
  isSpinning = true;
  spinButton.disabled = true;
  setMessage('Hjólið er að snúast...');
  const idx = prizes.findIndex(p=>p.id===result.prize.id);
  const index = idx < 0 ? prizes.length - 1 : idx;
  const slice=360/prizes.length;
  const centre=(index + .5) * slice;
  const jitter=(Math.random()-.5)*slice*.36;
  const target=7*360 - centre + jitter;
  wheel.style.transition='transform 6.3s cubic-bezier(.12,.67,.08,1)';
  // Ensure layout is committed before starting the transition.
  wheel.getBoundingClientRect();
  requestAnimationFrame(()=>{wheel.style.transform=`rotate(${target}deg)`;});
  await new Promise(resolve=>setTimeout(resolve,6500));
  isSpinning = false;
  if (isDemo) {
    setMessage('Þetta var prufusnúningur. Keyrðu vefþjóninn fyrir raunverulegan leik.');
    spinButton.disabled = false;
    spinButton.textContent = 'PRÓFA AFTUR ↗';
  } else setPlayed(result);
  showResult(result,isDemo);
}
form.addEventListener('submit',async event=>{
  event.preventDefault();
  if (isSpinning) return;
  if (alreadyPlayed && !isDemo) return showResult(alreadyPlayed);
  const username=input.value.trim().replace(/^@/,'').toLowerCase();
  if (!/^[a-z0-9._]{2,24}$/.test(username)) return setMessage('Sláðu inn gilt TikTok-notandanafn, 2 til 24 stafir.',true);
  spinButton.disabled=true;
  setMessage('Athuga þátttöku...');
  if (isDemo) {
    const prize=pickDemoPrize();
    wheel.style.transition='none'; wheel.style.transform='rotate(0deg)';
    await new Promise(r=>setTimeout(r,20));
    return spin({username,prize:{id:prize.id,title:prize.title,description:prize.description,win:prize.win},code:null});
  }
  try {
    const response=await fetch('/api/spin',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({username})});
    const data=await response.json();
    if (!response.ok) {
      if (data.alreadyPlayed) setPlayed(data.alreadyPlayed);
      else {spinButton.disabled=false;setMessage(data.error || 'Villa kom upp. Reyndu aftur.',true);}
      return;
    }
    return spin(data.result);
  } catch {
    spinButton.disabled=false;
    setMessage('Ekki náðist samband við þjóninn. Athugaðu nettenginguna.',true);
  }
});
$('hero-cta').addEventListener('click',()=>{ $('spila').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'}); setTimeout(()=>input.focus({preventScroll:true}),450); });
$('close-result').addEventListener('click',hideResult);
$('result-close-bottom').addEventListener('click',hideResult);
$('result-overlay').addEventListener('click',event=>{if(event.target===event.currentTarget) hideResult();});
document.addEventListener('keydown',event=>{
  if (event.key==='Escape'&&!$('result-overlay').hidden) hideResult();
  if (event.key==='Tab'&&!$('result-overlay').hidden) {
    const items=[...$('result-overlay').querySelectorAll('button:not([disabled]),a[href]')].filter(el=>el.getClientRects().length);
    const first=items[0],last=items[items.length-1];
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  }
});
$('copy-code').addEventListener('click',async()=>{
  try {
    await navigator.clipboard.writeText($('claim-code').textContent);
    $('copy-code').textContent='Afritað ✓';
  } catch { $('copy-code').textContent='Veldu kóðann'; }
});
spinButton.disabled=true;
loadConfig();
