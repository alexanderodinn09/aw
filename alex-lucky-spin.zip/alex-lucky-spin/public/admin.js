'use strict';
const $ = id => document.getElementById(id);
let adminKey = sessionStorage.getItem('alex_admin_key') || '';
let rows = [];

async function adminFetch(path,options={}) {
  const res=await fetch(path,{...options,cache:'no-store',headers:{'X-Admin-Key':adminKey,...(options.headers||{})}});
  if(!res.ok){let error;try{error=(await res.json()).error;}catch{}throw new Error(error||'Villa í tengingu');}
  return res;
}
async function loadDashboard() {
  const data=await (await adminFetch('/api/admin/spins')).json();
  $('dashboard').hidden=false;
  $('admin-message').textContent='Tengingin tókst.';
  $('campaign-label').textContent=`HERFERÐ / ${data.campaignId}`;
  rows=data.spins;
  $('total-count').textContent=rows.length;
  $('winner-count').textContent=rows.filter(s=>s.won).length;
  $('pending-count').textContent=rows.filter(s=>s.status==='pending').length;
  $('fulfilled-count').textContent=rows.filter(s=>s.status==='fulfilled').length;
  renderRows();
}
function renderRows(){
  const filter=$('status-filter').value;
  const body=$('spin-rows');body.replaceChildren();
  const filtered=filter==='all'?rows:rows.filter(s=>s.status===filter);
  if(!filtered.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=5;td.textContent='Engar niðurstöður hér ennþá.';td.className='table-empty';tr.appendChild(td);body.appendChild(tr);return;}
  for(const item of filtered){
    const tr=document.createElement('tr');
    const username=document.createElement('td');
    const a=document.createElement('a');a.href='https://www.tiktok.com/@'+encodeURIComponent(item.username);a.textContent='@'+item.username;a.target='_blank';a.rel='noopener noreferrer';username.appendChild(a);
    const prize=document.createElement('td');prize.textContent=item.prizeTitle; if(item.won) prize.className='win-tag';
    const code=document.createElement('td');const codeEl=document.createElement('code');codeEl.textContent=item.code||'—';code.appendChild(codeEl);
    const date=document.createElement('td');date.textContent=new Date(item.createdAt).toLocaleString('is-IS');
    const status=document.createElement('td');
    if(item.won){
      const select=document.createElement('select');
      [['pending','Óafgreitt'],['fulfilled','Afgreitt'],['rejected','Hafnað']].forEach(([value,label])=>{const option=document.createElement('option');option.value=value;option.textContent=label;select.appendChild(option);});
      select.value=item.status;
      select.addEventListener('change',async()=>{
        select.disabled=true;
        try {await adminFetch('/api/admin/spins/'+item.id,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:select.value})});item.status=select.value;await loadDashboard();}
        catch(err){alert(err.message);select.value=item.status;select.disabled=false;}
      });
      status.appendChild(select);
    }else{status.textContent='Enginn vinningur';}
    tr.append(username,prize,code,date,status);body.appendChild(tr);
  }
}
$('login').addEventListener('submit',async e=>{
  e.preventDefault();adminKey=$('admin-key').value.trim();
  $('admin-message').textContent='Tengist...';
  try{await loadDashboard();sessionStorage.setItem('alex_admin_key',adminKey);$('admin-key').value='';}
  catch(err){$('admin-message').textContent=err.message;$('dashboard').hidden=true;}
});
$('status-filter').addEventListener('change',renderRows);
$('refresh').addEventListener('click',async()=>{try{await loadDashboard();}catch(err){alert(err.message);}});
$('export').addEventListener('click',async()=>{
  try {
    const response=await adminFetch('/api/admin/export');
    const blob=await response.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='alex-winners.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }catch(err){alert(err.message);}
});
if(adminKey){$('admin-key').value=adminKey;loadDashboard().catch(()=>{sessionStorage.removeItem('alex_admin_key');adminKey='';});}
